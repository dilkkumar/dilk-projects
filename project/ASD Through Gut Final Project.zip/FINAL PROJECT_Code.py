#!/usr/bin/env python
# coding: utf-8

# In[2]:


# This Python 3 environment comes with many helpful analytics libraries installed
# It is defined by the kaggle/python Docker image: https://github.com/kaggle/docker-python
# For example, here's several helpful packages to load

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)

# Input data files are available in the read-only "../input/" directory
# For example, running this (by clicking run or pressing Shift+Enter) will list all files under the input directory

import os
for dirname, _, filenames in os.walk('/kaggle/input'):
    for filename in filenames:
        print(os.path.join(dirname, filename))

# You can write up to 20GB to the current directory (/kaggle/working/) that gets preserved as output when you create a version using "Save & Run All" 
# You can also write temporary files to /kaggle/temp/, but they won't be saved outside of the current session


# In[3]:


pip install scikit-learn


# In[4]:


import sklearn as sl


# In[5]:


pip install xgboost


# In[6]:


import xgboost


# In[7]:


import warnings
from sklearn.model_selection import StratifiedKFold
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.neural_network import MLPClassifier
from sklearn.model_selection import train_test_split
from sklearn.model_selection import GridSearchCV
from sklearn import preprocessing
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import RocCurveDisplay # to visualize prediction performance (ROC curve)
from sklearn.exceptions import ConvergenceWarning
import matplotlib.pyplot as plt
from sklearn import metrics
from sklearn.metrics import plot_confusion_matrix
# from sklearn.preprocessing import StandardScaler
import sklearn
from sklearn.metrics import f1_score, roc_auc_score, confusion_matrix, precision_recall_curve, auc, roc_curve, recall_score, precision_score
from xgboost import XGBClassifier

# some hyper parameters
SEED = 123
test_train_split_SEED = 123
# FOLDS = 10
show_fold_stats = True
VERBOSE = 0
FOLDS = 5

min_max_scaler = preprocessing.MinMaxScaler()
quantile_transformer = preprocessing.QuantileTransformer(random_state=SEED)
MLP_param_grid = [
        {
            'activation' : ['identity', 'logistic', 'tanh', 'relu'],
            'solver' : ['lbfgs', 'sgd', 'adam'],
            'hidden_layer_sizes': [
             (5,),(10,),(15,),(20,),(25,),(30,),(40,),(50,),(100,)
             ]
        }
       ]


# In[8]:


pd_abundance = pd.read_csv('./GSE113690_Autism_16S_rRNA_OTU_assignment_and_abundance.csv')
pd_meta_abundance = pd.read_csv('./ASD meta abundance.csv')
pd_meta_abundance
pd_meta_abundance.columns


# In[2]:


import pandas as pd
import matplotlib.pyplot as plt

# load data from a csv file
df1 = pd.read_csv('./ASD meta abundance.csv')
df1


# In[31]:


selected_rows = df1.iloc[[0, 2, 12,77,7], [0,3,6,36,50]]
selected_rows


# In[13]:


taxa = pd_meta_abundance[['A3', 'Taxonomy']].set_index('A3')
pd_meta_abundance_T = pd_meta_abundance.drop('Taxonomy', axis=1).set_index('A3').transpose()
print(pd_meta_abundance_T)
target = pd_meta_abundance_T.index.to_list()
print(target)
binary_target = np.array([0 if t.startswith('A') else 1 for t in target ])

total_species = pd_meta_abundance_T.sum(axis = 1)
print(total_species)
abs_abundance = 31757
pd_rel_meta_abundance = pd_meta_abundance_T / abs_abundance 
print(pd_rel_meta_abundance)


# In[21]:


# exclude absent spcecies
pd_meta_abundance = pd_meta_abundance[pd_meta_abundance.sum(axis = 1) !=0]


# In[17]:


print("first 5 rows:")
# Print the first 5 rows of the data
pd_meta_abundance.head()


# In[22]:


pd_meta_abndc = pd_meta_abundance.drop(['Taxonomy'], axis=1).T
target = pd_meta_abndc.index.to_list()
binary_target = np.array([0 if t.startswith('A') else 1 for t in target ])


# In[23]:


print("first 5 rows:")
# Print the first 5 rows of the data
pd_meta_abndc.head()


# In[24]:


# Lets put aside a small test set, so we can check performance of different classifiers against it
disease_train, disease_test, disease_y_train, disease_y_test = train_test_split(pd_meta_abndc, binary_target, test_size = 0.2,  random_state = test_train_split_SEED , shuffle = True) 


# In[25]:


print("train data shape:")
# Print the first 5 rows of the data
disease_train.shape


# In[26]:


print("test data shape:")
# Print the first 5 rows of the data
disease_test.shape


# In[27]:


print("first 5 rows:")
# Print the first 5 rows of the data
disease_train.head()


# In[28]:


# this subset of data is too small to have a separate test set, so we'd have to rely on CV only
skf = StratifiedKFold(n_splits = FOLDS, shuffle = True, random_state = SEED)
# for fold, (idxT,idxV) in enumerate(skf.split(pd_meta_abndc, binary_target)):
for fold, (idxT,idxV) in enumerate(skf.split(disease_train, disease_y_train)):    
    # set training and validation indices
    X_train = disease_train.iloc[idxT]
    X_val = disease_train.iloc[idxV]
    y_train = disease_y_train[idxT]
    y_val = disease_y_train[idxV]
    
    
    # Random Forest
    clf = RandomForestClassifier(n_estimators = 500, random_state = SEED, verbose = 0)
    clf.fit(X_train, y_train )

    RF_pred_class = clf.predict(X_val)
    RF_preds = clf.predict_proba(X_val)
    
    RF_AUC_test_score = roc_auc_score(y_val, RF_preds[:,1])
    RF_f1_test = f1_score(y_val, RF_pred_class)
    RF_recall_test = recall_score(y_val, RF_pred_class)
    RF_precision_test = precision_score(y_val, RF_pred_class)
    
    if show_fold_stats:
        print('-' * 80)
        print('Fold : %s'%(fold+1))
        print('ROC AUC score for RandomForest model, validation set: %.4f'%RF_AUC_test_score)
        print('F1 : %.4f, Recall : %.4f , Precision : %.4f'%(RF_f1_test, RF_recall_test, RF_precision_test))
        print(confusion_matrix(y_val, RF_pred_class))
    
    
    # Logistic Regression
    LogReg_model = LogisticRegression(random_state=SEED)
    LogReg_model.fit(X_train, y_train)
    LogReg_preds = LogReg_model.predict_proba(X_val)
    LogReg_class = LogReg_model.predict(X_val)

    LogReg_score = roc_auc_score(y_val, LogReg_preds[:,1])
    LogReg_f1 = f1_score(y_val, LogReg_class)
    LogReg_recall = recall_score(y_val, LogReg_class)
    LogReg_precision = precision_score(y_val, LogReg_class)
    
    if show_fold_stats:        
        print('ROC AUC score for Logistic Regression model, validation set: %.4f'%LogReg_score)
        print('F1 : %.4f, Recall : %.4f , Precision : %.4f'%(LogReg_f1, LogReg_recall, LogReg_precision))
        print(confusion_matrix(y_val, LogReg_class))
    
    # Feedforward neural network (multilayer perceptron)
    
    # hyperparameter tuning (optional)
    # MLP_model = GridSearchCV(MLPClassifier(max_iter=1000,random_state=SEED), MLP_param_grid, cv=3,
    #                           scoring='accuracy')
  

    MLP_model = MLPClassifier(hidden_layer_sizes=(50,),max_iter=500,random_state=SEED)
    # you can set hyperparameters see: https://scikit-learn.org/stable/modules/generated/sklearn.neural_network.MLPClassifier.html
    # some parameter combinations will not converge as can be seen on the
    # plots so they are ignored here
    with warnings.catch_warnings():
        warnings.filterwarnings(
            "ignore", category=ConvergenceWarning, module="sklearn"
        )
        MLP_model.fit(X_train, y_train)
        
    #     print("Best parameters set found on development set:")
    #     print(MLP_model.best_params_)
    MLP_preds = MLP_model.predict_proba(X_val)
    MLP_class = MLP_model.predict(X_val)

    MLP_score = roc_auc_score(y_val, MLP_preds[:,1])
    MLP_f1 = f1_score(y_val, MLP_class)
    MLP_recall = recall_score(y_val, MLP_class)
    MLP_precision = precision_score(y_val, MLP_class)
    
    if show_fold_stats:        
        print('ROC AUC score for MLP model, validation set: %.4f'%MLP_score)
        print('F1 : %.4f, Recall : %.4f , Precision : %.4f'%(MLP_f1, MLP_recall, MLP_precision))
        print(confusion_matrix(y_val, MLP_class))
        
    # XGBoost
    XGB_model = XGBClassifier(n_estimators=5000, max_depth=None, 
                        learning_rate=0.005,
                        objective='binary:logistic', 
                        metric='auc',
                        verbosity  = VERBOSE,
                        # tree_method = 'gpu_hist',
                        use_label_encoder=False,
                        n_jobs=-1, random_state  = SEED )
    
    XGB_model.fit(X_train, y_train,
                    eval_set = [(X_val, y_val)],
                    eval_metric=['logloss'],
                    early_stopping_rounds = 100, verbose = VERBOSE )
        
    XGB_preds = XGB_model.predict_proba(X_val)
    XGB_class = XGB_model.predict(X_val)

    XGB_score = roc_auc_score(y_val, XGB_preds[:,1])
    XGB_f1 = f1_score(y_val, XGB_class)
    XGB_recall = recall_score(y_val, XGB_class)
    XGB_precision = precision_score(y_val, XGB_class)

    if show_fold_stats:        
        print('ROC AUC score for XGBoost model, validation set: %.4f'%XGB_score)
        print('F1 : %.4f, Recall : %.4f , Precision : %.4f'%(XGB_f1, XGB_recall, XGB_precision))
        print(confusion_matrix(y_val, XGB_class))


# In[29]:


# Now we can train the learners (models) with the whole training dataset and evaluate the models on the test set
X_train = disease_train
X_val = disease_train
y_train = disease_y_train
y_val = disease_y_train
    
    
# Random Forest
clf = RandomForestClassifier(n_estimators = 500, random_state = SEED, verbose = 0)
clf.fit(X_train, y_train )

RF_pred_class = clf.predict(X_val)
RF_preds = clf.predict_proba(X_val)

RF_AUC_test_score = roc_auc_score(y_val, RF_preds[:,1])
RF_f1_test = f1_score(y_val, RF_pred_class)
RF_recall_test = recall_score(y_val, RF_pred_class)
RF_precision_test = precision_score(y_val, RF_pred_class)
    
if show_fold_stats:
    print('-' * 80)
    print('Fold : %s'%(fold+1))
    print('ROC AUC score for RandomForest model, validation set: %.4f'%RF_AUC_test_score)
    print('F1 : %.4f, Recall : %.4f , Precision : %.4f'%(RF_f1_test, RF_recall_test, RF_precision_test))
    print(confusion_matrix(y_val, RF_pred_class))
    
    
# Logistic Regression
LogReg_model = LogisticRegression(random_state=SEED)
LogReg_model.fit(X_train, y_train)
LogReg_preds = LogReg_model.predict_proba(X_val)
LogReg_class = LogReg_model.predict(X_val)

LogReg_score = roc_auc_score(y_val, LogReg_preds[:,1])
LogReg_f1 = f1_score(y_val, LogReg_class)
LogReg_recall = recall_score(y_val, LogReg_class)
LogReg_precision = precision_score(y_val, LogReg_class)
    
if show_fold_stats:        
    print('ROC AUC score for Logistic Regression model, validation set: %.4f'%LogReg_score)
    print('F1 : %.4f, Recall : %.4f , Precision : %.4f'%(LogReg_f1, LogReg_recall, LogReg_precision))
    print(confusion_matrix(y_val, LogReg_class))

# Feedforward neural network (multilayer perceptron)

# hyperparameter tuning (optional)
# MLP_model = GridSearchCV(MLPClassifier(max_iter=1000,random_state=SEED), MLP_param_grid, cv=3,
#                           scoring='accuracy')


MLP_model = MLPClassifier(hidden_layer_sizes=(50,),max_iter=500,random_state=SEED)
# you can set hyperparameters see: https://scikit-learn.org/stable/modules/generated/sklearn.neural_network.MLPClassifier.html
# some parameter combinations will not converge as can be seen on the
# plots so they are ignored here
with warnings.catch_warnings():
    warnings.filterwarnings(
        "ignore", category=ConvergenceWarning, module="sklearn"
    )
    MLP_model.fit(X_train, y_train)

#     print("Best parameters set found on development set:")
#     print(MLP_model.best_params_)
MLP_preds = MLP_model.predict_proba(X_val)
MLP_class = MLP_model.predict(X_val)

MLP_score = roc_auc_score(y_val, MLP_preds[:,1])
MLP_f1 = f1_score(y_val, MLP_class)
MLP_recall = recall_score(y_val, MLP_class)
MLP_precision = precision_score(y_val, MLP_class)

if show_fold_stats:        
    print('ROC AUC score for MLP model, validation set: %.4f'%MLP_score)
    print('F1 : %.4f, Recall : %.4f , Precision : %.4f'%(MLP_f1, MLP_recall, MLP_precision))
    print(confusion_matrix(y_val, MLP_class))

# XGBoost
XGB_model = XGBClassifier(n_estimators=5000, max_depth=None, 
                    learning_rate=0.005,
                    objective='binary:logistic', 
                    metric='auc',
                    verbosity  = VERBOSE,
                    # tree_method = 'gpu_hist',
                    use_label_encoder=False,
                    n_jobs=-1, random_state  = SEED )

XGB_model.fit(X_train, y_train,
                eval_set = [(X_val, y_val)],
                eval_metric=['logloss'],
                early_stopping_rounds = 100, verbose = VERBOSE )

XGB_preds = XGB_model.predict_proba(X_val)
XGB_class = XGB_model.predict(X_val)

XGB_score = roc_auc_score(y_val, XGB_preds[:,1])
XGB_f1 = f1_score(y_val, XGB_class)
XGB_recall = recall_score(y_val, XGB_class)
XGB_precision = precision_score(y_val, XGB_class)

if show_fold_stats:        
    print('ROC AUC score for XGBoost model, validation set: %.4f'%XGB_score)
    print('F1 : %.4f, Recall : %.4f , Precision : %.4f'%(XGB_f1, XGB_recall, XGB_precision))
    print(confusion_matrix(y_val, XGB_class))  

        
        
        
        
RF_preds_test = clf.predict_proba(disease_test)
XGB_preds_test = XGB_model.predict_proba(disease_test)
LogReg_preds_test = LogReg_model.predict_proba(disease_test)
MLP_preds_test = MLP_model.predict_proba(disease_test)
avg_preds_test = (RF_preds_test[:,1] + XGB_preds_test[:,1] + LogReg_preds_test[:,1] + MLP_preds_test[:,1]) / 4

RF_test_AUC = roc_auc_score(disease_y_test, RF_preds_test[:,1])
print('ROC AUC score for RF for test set: %.4f'%RF_test_AUC)
XGB_test_AUC = roc_auc_score(disease_y_test, XGB_preds_test[:,1])
print('ROC AUC score for XGBoost model test set: %.4f'%XGB_test_AUC)
LogReg_test_AUC = roc_auc_score(disease_y_test, LogReg_preds_test[:,1])
print('ROC AUC score for Logistic Regression for test set: %.4f'%LogReg_test_AUC)
MLP_test_AUC = roc_auc_score(disease_y_test, MLP_preds_test[:,1])
print('ROC AUC score for MLP for test set: %.4f'%MLP_test_AUC)
average_AUC = roc_auc_score(disease_y_test, avg_preds_test )
print('ROC AUC score averaged between 2 models for test set: %.4f'%average_AUC)
    
avg_class = np.where(avg_preds_test < 0.7, 0, 1)
print('F1 : %.4f, Recall : %.4f , Precision : %.4f'%(f1_score(disease_y_test, avg_class), recall_score(disease_y_test, avg_class), precision_score(disease_y_test, avg_class)))
print(confusion_matrix(disease_y_test, avg_class))
    
# ax = plt.gca()
RF_disp = metrics.plot_roc_curve(clf, disease_test, disease_y_test)
RF_CM = metrics.plot_confusion_matrix(clf, disease_test, disease_y_test)  
LogReg_disp = metrics.plot_roc_curve(LogReg_model, disease_test, disease_y_test)
LogReg_CM = metrics.plot_confusion_matrix(LogReg_model, disease_test, disease_y_test)
MLP_disp = metrics.plot_roc_curve(MLP_model, disease_test, disease_y_test)
MLP_CM = metrics.plot_confusion_matrix(MLP_model, disease_test, disease_y_test)
XGB_disp = metrics.plot_roc_curve(XGB_model, disease_test, disease_y_test)
XGB_CM = metrics.plot_confusion_matrix(XGB_model, disease_test, disease_y_test)

# RF_disp = RocCurveDisplay.from_estimator(clf, X_test, y_test, ax=ax, alpha=0.8)
# LogReg_disp = RocCurveDisplay.from_estimator(LogReg_model, X_test, y_test, ax=ax, alpha=0.8)
# MLP_disp = RocCurveDisplay.from_estimator(MLP_model, X_test, y_test, ax=ax, alpha=0.8)
# XGB_disp = RocCurveDisplay.from_estimator(XGB_model, X_test, y_test, ax=ax, alpha=0.8)
# plt.plot(ax=ax, alpha=0.8)
plt.show()


# In[ ]:




